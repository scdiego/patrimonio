/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Presentacion.MainFormOld;
import java.math.BigDecimal;

/**
 *
 * @author Mónica Mounier - Demián Kachuk
 */
public class MainClass {
    
    /**
     * Instancio la clase que controla el acceso a la capa siguiente.
     */
//    CtrlPersistencia persistencia = new CtrlPersistencia();
//    http://www.javatutoriales.com/2009/02/creacion-de-reportes-con-jasperrepots-y.html
    /**
     * 
     */
   // static Agencia unaAgencia = new Agencia();
  
    /**
     * Punto de entrada al Sistema
     * @param args 
     */
    public static void main(String[] args) {
        
     //   MainForm ventanaSistema = new MainForm();
     //   ventanaSistema.setLocationRelativeTo(null);
     //   ventanaSistema.inicializaVentana();
        
        //Inventario unInventario = new Inventario();
        //unInventario.agregarSector("Tecnica");
       // System.out.println() ;
       //    public Bien crearBien (String codigo, Integer nroInventario, String descripcion, Date fechaAlta, String nroActa, BigDecimal valor,  String nroExpedienteAlta, String resolucionAlta) {

       
       
       Inventario unInventario = new Inventario();
   //    Sector unSector = new Sector();
   //    Responsable unResponsable = new Responsable();
   /*
       unInventario.nuevoBien("001", 1, "Mate", null, null, null, null, null);
       unInventario.nuevoBien("002", 2, "Bombilla", null, null, null, null, null);
       unInventario.nuevoBien("005", 5, "Termo", null, null, null, null, null);
       unInventario.nuevoBien("004", 4, "Yerba", null, null, null, null, null);
       unInventario.nuevoBien("003", 3, "Chipitas", null, null, null, null, null);
       
       System.out.println(unInventario.buscar(4,2));
*/
       
       
       
    }

    
}
