# patrimonio

## Dependencies
- [Mysql Connector/J](https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.11.zip)
- [Jasper Reports 6.2](https://sourceforge.net/projects/jasperreports/files/jasperreports/JasperReports%206.2.1/jasperreports-6.2.1.jar/download)

## Persistence's status

| POJO        | Create           | Read  |Update | Delete |
| ----------- |:----------------:| -----:|------:|-------:|
| Asignacion  |X
| Bien        |X                 |X
| Inventario  |
| Responsable |X                 |X      |        |
| Sector      |X                 |X      |X       |X
| Usuario     |X                 |X      |X       |X
